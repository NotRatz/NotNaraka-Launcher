NotNaraka Launcher v1.0.0

INSTALLATION INSTRUCTIONS:

1. Run install.bat
2. Follow the on-screen prompts

REQUIREMENTS:

- Windows 10/11 64-bit
- .NET 8.0 Desktop Runtime

If you don't have .NET installed, the installer will offer to open the download page.

FEATURES:

- Launch Naraka: Bladepoint
- Download CN and Global clients
- System performance tweaks
- Steam news feed
- Real-time logging

